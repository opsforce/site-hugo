# Community features

<!--
Did a cool thing with the theme and want to share it with rest of the Hello Friend theme users? Jump in!

Please follow the template:

- **NAME_OF_THE_FEATURE** (LINK TO YOUR FORK)
  - SHORT DESCRIPTION
  - SOMETHING ABOUT YOU (name and who you are / what you do / etc.)

eg:

- **Social media icons** (https://github.com/...)
  - This was a big missing feature of the theme. It will help your audience reach you over the internet.
  - John, a javascript developer.
-->
